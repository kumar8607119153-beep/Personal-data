# BTC Delta Option Intelligence — Streamlit

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Streamlit Cloud
1. Upload `app.py` and `requirements.txt` to a GitHub repository.
2. In Streamlit Community Cloud choose **New app**.
3. Select the repository and `app.py`.
4. Deploy.

This app uses Delta Exchange India's public market-data REST API. No API key or secret is required for these public endpoints. It does not place orders.

The current build uses REST polling for reliable browser-hosted Streamlit deployment. It continuously refreshes the BTC price, option chain, every strike, and expiry ranking. The technical candle-indicator layer can be added using Delta's public candlestick feed/endpoints.
