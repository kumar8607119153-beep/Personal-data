import streamlit as st
import requests, pandas as pd, numpy as np, math, time
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

BASE="https://api.india.delta.exchange"
WS_URL="wss://public-socket.india.delta.exchange"

st.set_page_config(page_title="BTC Delta Option Intelligence", page_icon="₿", layout="wide")

st.markdown("""
<style>
.block-container{padding-top:1rem;padding-bottom:1rem}
[data-testid="stMetricValue"]{font-size:1.35rem}
div[data-testid="stDataFrame"]{font-size:12px}
</style>
""", unsafe_allow_html=True)

def num(x):
    try:
        if x is None or x=="" or x=="null": return np.nan
        return float(x)
    except: return np.nan

def first(d,*keys):
    for k in keys:
        v=d.get(k)
        if v is not None and v!="": return v
    return None

def api_get(path, params=None, timeout=12):
    r=requests.get(BASE+path, params=params or {}, headers={"Accept":"application/json"}, timeout=timeout)
    r.raise_for_status()
    j=r.json()
    if not j.get("success", True):
        raise RuntimeError(str(j))
    return j.get("result", j)

def greeks(t):
    g=t.get("greeks") or {}
    if isinstance(g,list):
        return {"delta":num(g[0]) if len(g)>0 else np.nan,
                "gamma":num(g[1]) if len(g)>1 else np.nan,
                "theta":num(g[2]) if len(g)>2 else np.nan,
                "vega":num(g[3]) if len(g)>3 else np.nan}
    return {"delta":num(first(g,"delta","Delta")),
            "gamma":num(first(g,"gamma","Gamma")),
            "theta":num(first(g,"theta","Theta")),
            "vega":num(first(g,"vega","Vega"))}

def ticker_rows(result):
    if isinstance(result,dict):
        for k in ("result","data","tickers"):
            if isinstance(result.get(k),list): return result[k]
        return [result]
    return result if isinstance(result,list) else []

@st.cache_data(ttl=8, show_spinner=False)
def get_products():
    return ticker_rows(api_get("/v2/tickers", {"contract_types":"call_options,put_options"}))

@st.cache_data(ttl=5, show_spinner=False)
def get_chain(expiry):
    return ticker_rows(api_get("/v2/tickers", {
        "contract_types":"call_options,put_options",
        "underlying_asset_symbols":"BTC",
        "expiry_date":expiry
    }))

@st.cache_data(ttl=3, show_spinner=False)
def get_btc():
    try:
        x=api_get("/v2/tickers/BTCUSD")
        if isinstance(x,list): x=x[0]
        return x
    except:
        rows=ticker_rows(api_get("/v2/tickers", {"contract_types":"perpetual_futures"}))
        for x in rows:
            if x.get("symbol")=="BTCUSD": return x
        return {}

def expiry_to_dt(e):
    try:
        return datetime.strptime(e,"%d-%m-%Y").replace(tzinfo=timezone.utc)
    except: return None

def expiry_ws(e):
    return "BTC-"+datetime.strptime(e,"%d-%m-%Y").strftime("%d%m%y")

def option_score(t, spot):
    if not t: return -999
    ltp=num(first(t,"close","mark_price","ltp"))
    oi=num(t.get("oi", t.get("open_interest")))
    vol=num(t.get("volume"))
    iv=num(first(t,"iv","implied_volatility"))
    g=greeks(t)
    d=abs(g["delta"]) if np.isfinite(g["delta"]) else 0
    score=0
    if np.isfinite(ltp) and ltp>0: score += min(30,10+10*math.log10(max(1,ltp)))
    if np.isfinite(oi): score += min(25, math.log1p(max(0,oi))*2)
    if np.isfinite(vol): score += min(20, math.log1p(max(0,vol))*2)
    if np.isfinite(iv): score += max(0,min(10,20-abs(iv-0.8)*10))
    score += min(15,d*15)
    return score

def build_chain(rows, spot):
    calls={}; puts={}
    for t in rows:
        sym=str(t.get("symbol",""))
        strike=num(t.get("strike_price"))
        ct=str(t.get("contract_type","")).lower()
        if not np.isfinite(strike):
            parts=sym.split("-")
            if len(parts)>=4: strike=num(parts[2])
        if not np.isfinite(strike): continue
        if "call" in ct or sym.startswith("C-"): calls[strike]=t
        elif "put" in ct or sym.startswith("P-"): puts[strike]=t
    strikes=sorted(set(calls)|set(puts))
    out=[]
    for s in strikes:
        c,p=calls.get(s),puts.get(s)
        cg=greeks(c or {}); pg=greeks(p or {})
        cl=num(first(c or {},"close","mark_price","ltp")); pl=num(first(p or {},"close","mark_price","ltp"))
        cs=option_score(c,spot); ps=option_score(p,spot)
        out.append({
            "Strike":s,
            "CE LTP":cl,"CE Δ":cg["delta"],"CE Γ":cg["gamma"],"CE Θ":cg["theta"],"CE Vega":cg["vega"],
            "CE IV":num(first(c or {},"iv","implied_volatility")),
            "CE OI":num((c or {}).get("oi",(c or {}).get("open_interest"))),"CE Vol":num((c or {}).get("volume")),"CE Score":cs,
            "PE LTP":pl,"PE Δ":pg["delta"],"PE Γ":pg["gamma"],"PE Θ":pg["theta"],"PE Vega":pg["vega"],
            "PE IV":num(first(p or {},"iv","implied_volatility")),
            "PE OI":num((p or {}).get("oi",(p or {}).get("open_interest"))),"PE Vol":num((p or {}).get("volume")),"PE Score":ps,
            "Distance %": abs(s-spot)/spot*100 if spot else np.nan,
            "Result":"CE" if cs>=ps else "PE"
        })
    return pd.DataFrame(out)

def technicals_from_chain(df, spot):
    if df.empty: return {}
    atm=df.iloc[(df["Strike"]-spot).abs().argsort()[:1]]
    if atm.empty: return {}
    row=atm.iloc[0]
    return {"ATM Strike":row["Strike"],"ATM CE":row["CE LTP"],"ATM PE":row["PE LTP"]}

st.title("₿ BTC Delta Option Intelligence")
st.caption("Live market-data analysis • No order execution • Public Delta Exchange India feed")

refresh=st.sidebar.slider("Refresh interval (seconds)", 3, 30, 8)
auto=st.sidebar.checkbox("Auto refresh", True)
st.sidebar.button("Refresh now", on_click=lambda: st.cache_data.clear())
st.sidebar.markdown("**Feed:** Delta Exchange India public API")
st.sidebar.markdown("**Trading:** Disabled")

try:
    btc=get_btc()
    spot=num(first(btc,"spot_price","close","mark_price","last_price"))
    ltp=num(first(btc,"close","last_price","mark_price"))
    ch=num(first(btc,"ltp_change_24h","change_24h"))
    oi=num(first(btc,"oi","open_interest"))
except Exception as e:
    st.error(f"BTC feed error: {e}")
    btc={}; spot=ltp=ch=oi=np.nan

c1,c2,c3,c4=st.columns(4)
c1.metric("BTC Price", f"${ltp:,.2f}" if np.isfinite(ltp) else "—")
c2.metric("Spot / Index", f"${spot:,.2f}" if np.isfinite(spot) else "—")
c3.metric("24h Change", f"{ch:.2f}%" if np.isfinite(ch) else "—")
c4.metric("Perpetual OI", f"{oi:,.0f}" if np.isfinite(oi) else "—")

try:
    products=get_products()
    expiries=sorted({str(x.get("expiry_date")) for x in products if x.get("expiry_date")}, key=lambda e: expiry_to_dt(e) or datetime.max.replace(tzinfo=timezone.utc))
except Exception as e:
    products=[]; expiries=[]; st.warning(f"Expiry feed error: {e}")

if not expiries:
    st.warning("No future BTC option expiries returned by Delta at the moment.")
    st.stop()

selected=st.selectbox("BTC Option Expiry", expiries, format_func=lambda e: f"{e} ({max(0,(expiry_to_dt(e)-datetime.now(timezone.utc)).days)} days)")
rows=get_chain(selected)
df=build_chain(rows, spot if np.isfinite(spot) else 0)

if df.empty:
    st.warning("No option-chain rows returned for the selected expiry.")
else:
    pcr=df["PE OI"].sum()/df["CE OI"].sum() if df["CE OI"].sum()>0 else np.nan
    best=df.iloc[df[["CE Score","PE Score"]].max(axis=1).idxmax()]
    top_side=best["Result"]
    best_score=max(best["CE Score"],best["PE Score"])
    m1,m2,m3,m4=st.columns(4)
    m1.metric("PCR (OI)", f"{pcr:.3f}" if np.isfinite(pcr) else "—")
    m2.metric("Best Strike", f"{best['Strike']:,.0f} {top_side}")
    m3.metric("Best Score", f"{best_score:.1f}")
    m4.metric("ATM", f"{df.iloc[(df['Strike']-(spot if np.isfinite(spot) else 0)).abs().argsort()[0]]['Strike']:,.0f}")

    st.subheader("Every Strike — Live Option Chain")
    cols=["Strike","CE LTP","CE Δ","CE Γ","CE Θ","CE Vega","CE IV","CE OI","CE Vol","CE Score",
          "PE LTP","PE Δ","PE Γ","PE Θ","PE Vega","PE IV","PE OI","PE Vol","PE Score","Distance %","Result"]
    st.dataframe(df[cols].round(4), use_container_width=True, height=600)

    st.subheader("Per-Strike Detailed Analysis")
    detail=df.copy()
    detail["Moneyness"]=np.where(detail["Strike"]<spot,"ITM/OTM by side",np.where(detail["Strike"]>spot,"OTM/ITM by side","ATM"))
    st.dataframe(detail.round(4), use_container_width=True, height=450)

st.subheader("Expiry Intelligence — All Available Expiries")
expiry_rows=[]
for e in expiries[:20]:
    try:
        d=expiry_to_dt(e)
        days=max(0,(d-datetime.now(timezone.utc)).total_seconds()/86400) if d else np.nan
        r=get_chain(e)
        dd=build_chain(r,spot if np.isfinite(spot) else 0)
        if dd.empty: continue
        scores=dd[["CE Score","PE Score"]].max(axis=1)
        top=float(scores.max()); avg=float(scores.nlargest(min(3,len(scores))).mean())
        liq=float(np.nanmean(np.log1p(dd[["CE OI","PE OI","CE Vol","PE Vol"]].clip(lower=0).values)))
        risk="HIGH" if days<1 else ("MEDIUM" if days<3 else "LOW")
        potential=top*0.55+avg*0.30+liq*5
        br=dd.iloc[scores.argmax()]
        expiry_rows.append({"Rank":0,"Expiry":e,"Days":round(days,2),"Best CE":round(br["CE Score"],1),"Best PE":round(br["PE Score"],1),
                            "Top Score":round(top,1),"Avg Top-3":round(avg,1),"Liquidity":round(liq,2),"Expiry Risk":risk,"Potential":round(potential,1)})
    except Exception:
        continue
if expiry_rows:
    exdf=pd.DataFrame(expiry_rows).sort_values("Potential",ascending=False).reset_index(drop=True)
    exdf["Rank"]=np.arange(1,len(exdf)+1)
    st.dataframe(exdf,use_container_width=True)
    topx=exdf.iloc[0]
    st.success(f"Highest potential expiry: {topx['Expiry']} • Potential {topx['Potential']} • Risk {topx['Expiry Risk']}")
else:
    st.info("Expiry comparison unavailable right now.")

st.subheader("Technical / Decision Panel")
if np.isfinite(spot) and not df.empty:
    atmrow=df.iloc[(df["Strike"]-spot).abs().argsort()[0]]
    ce=atmrow["CE LTP"]; pe=atmrow["PE LTP"]
    st.write(f"**ATM:** {atmrow['Strike']:,.0f} | CE {ce:,.2f} | PE {pe:,.2f} | Preferred side: **{atmrow['Result']}**")
    st.caption("Technical candle indicators require BTCUSD OHLC history; this Streamlit build keeps the live option engine primary. Add historical candle endpoint/WebSocket candles for Supertrend/VWAP/MACD/Bollinger/ADX if desired.")

now=datetime.now(ZoneInfo("Asia/Kolkata")).strftime("%d-%m-%Y %H:%M:%S")
st.caption(f"Last refresh: {now} IST")

if auto:
    time.sleep(refresh)
    st.rerun()
